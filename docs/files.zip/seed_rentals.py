#!/usr/bin/env python3
"""
seed_rentals.py — generates the Data Analyst unit 3 dataset.

Produces two files:
  jintu_rentals_raw.csv   the learner sees this
  answer-key.json        service role only, never in the public repo

WHY THIS FILE IS THE MOST VALUABLE THING IN THE REPO
The answer key does not exist on the internet. A learner cannot ask a chatbot
what is wrong with this dataset, because nobody has ever seen it. That is what
makes unit 3 gradeable at zero cost and un-replicable by a competitor with the
same idea and a good prompt.

THREE RULES THE GENERATOR ENFORCES
1. Realistic frequencies. A defect in 40% of rows is a tutorial. One in 0.3% of
   rows is the job. Every rate here is deliberately low.
2. Decoys are mandatory. Things that look wrong and are correct. Without them
   you test thoroughness, which is what a chatbot is already good at. With
   them you test judgement, which it is not.
3. Rotation by seed. Change ROTATION and every count moves, so a leaked key
   from last quarter is worthless. Assume any key older than three rotations
   is public.

The key's shape matches the AnswerKey interface in
packages/grading/src/checkers/answerKey.ts exactly. The match is on
(column, rows_affected) — the row count is the fingerprint, which is why the
artifact prompt requires learners to report counts.
"""

from __future__ import annotations
import csv, json, random, hashlib
from dataclasses import dataclass, field, asdict
from datetime import date, timedelta
from pathlib import Path

# --------------------------------------------------------------------------
# Rotation. Bump this each quarter. Every planted count shifts with it.
# --------------------------------------------------------------------------
ROTATION = 1
BASE_ROWS = 4200
OUT = Path(__file__).parent / "out"

SEED = int(hashlib.sha256(f"jintu-rentals-r{ROTATION}".encode()).hexdigest()[:8], 16)
rng = random.Random(SEED)

CITIES = ["Mumbai", "Pune", "Bengaluru", "Chennai", "Hyderabad", "Kolkata",
          "Ahmedabad", "Jaipur", "Lucknow", "Kochi"]
CATEGORIES = ["Action", "Comedy", "Documentary", "Drama", "Family",
              "Horror", "Sci-Fi", "Animation"]
FIRST = ["Rajesh", "Priya", "Amit", "Sneha", "Vikram", "Anita", "Rahul", "Divya",
         "Karthik", "Meera", "Suresh", "Kavya", "Arjun", "Pooja", "Nikhil"]
LAST = ["Kumar", "Sharma", "Patel", "Reddy", "Iyer", "Singh", "Nair", "Gupta",
        "Desai", "Menon", "Joshi", "Rao"]

START = date(2024, 1, 1)
END = date(2025, 12, 31)
TODAY = date(2026, 8, 12)   # "now" for the future-dates defect


@dataclass
class Row:
    rental_id: int
    customer_name: str
    city: str
    film_title: str
    category: str
    rental_date: str
    return_date: str
    rental_days: str
    amount: str
    staff_rating: str

    def as_dict(self) -> dict:
        return asdict(self)


@dataclass
class KeyEntry:
    """Mirrors KeyEntry in answerKey.ts. Do not drift."""
    id: str
    label: str
    columns: list[str]
    rowsAffected: int | None = None
    matchAny: list[str] = field(default_factory=list)
    isDecoy: bool = False
    # Not sent to the checker — for the human grader and the rotation log.
    note: str = ""


def rand_date(a: date, b: date) -> date:
    return a + timedelta(days=rng.randint(0, (b - a).days))


def clean_rows(n: int) -> list[Row]:
    rows = []
    for i in range(1, n + 1):
        rd = rand_date(START, END)
        days = rng.choice([3, 3, 5, 5, 7, 7, 7, 10, 14])
        rows.append(Row(
            rental_id=i,
            customer_name=f"{rng.choice(FIRST)} {rng.choice(LAST)}",
            city=rng.choice(CITIES),
            film_title=f"Film {rng.randint(100, 999)}",
            category=rng.choice(CATEGORIES),
            rental_date=rd.isoformat(),
            return_date=(rd + timedelta(days=days)).isoformat(),
            rental_days=str(days),
            amount=f"{rng.choice([49, 99, 149, 199, 249]):.2f}",
            staff_rating=str(rng.randint(1, 5)),
        ))
    return rows


def plant(rows: list[Row]) -> list[KeyEntry]:
    """
    Ten defect classes plus two decoys. Counts are jittered by rotation so a
    leaked key expires. Every count is recorded in the key — that count is what
    the checker matches on.
    """
    keys: list[KeyEntry] = []
    n = len(rows)
    used: set[int] = set()

    def pick(k: int) -> list[int]:
        avail = [i for i in range(n) if i not in used]
        chosen = rng.sample(avail, k)
        used.update(chosen)
        return chosen

    def jitter(base: int, spread: int = 3) -> int:
        return max(2, base + rng.randint(-spread, spread))

    # 1. Exact duplicate rows. Appended, so the count is rows ADDED.
    dup_n = jitter(14)
    for i in rng.sample(range(n), dup_n):
        rows.append(Row(**rows[i].as_dict()))
    keys.append(KeyEntry("d01", "Exact duplicate rows", ["rental_id"], dup_n,
                         ["duplicate", "dupe", "repeated row", "identical row"],
                         note="Whole rows appended verbatim. Detect with GROUP BY on all columns."))

    # 2. Near-duplicate entities. One customer, several spellings.
    victim = "Rajesh Kumar"
    variants = ["rajesh kumar", "Rajesh  Kumar", "RAJESH KUMAR", " Rajesh Kumar"]
    near_n = jitter(11)
    for idx, i in enumerate(pick(near_n)):
        rows[i].customer_name = variants[idx % len(variants)]
    keys.append(KeyEntry("d02", "Near-duplicate customer names", ["customer_name"], near_n,
                         ["near duplicate", "same customer", "case", "whitespace", "trailing space"],
                         note=f"All refer to {victim}. Clustering or lower(trim()) finds them."))

    # 3. Mixed date formats in one column.
    fmt_n = jitter(23)
    for idx, i in enumerate(pick(fmt_n)):
        d = date.fromisoformat(rows[i].rental_date)
        rows[i].rental_date = [
            d.strftime("%d/%m/%Y"), d.strftime("%d-%b-%y"), d.strftime("%m/%d/%Y"),
        ][idx % 3]
    keys.append(KeyEntry("d03", "Mixed date formats", ["rental_date"], fmt_n,
                         ["date format", "inconsistent date", "mixed format", "dd/mm"],
                         note="Includes ambiguous dd/mm vs mm/dd. Worth a mention if they spot it."))

    # 4. Impossible durations — return precedes rental.
    imp_n = jitter(6, 2)
    for i in pick(imp_n):
        rd = date.fromisoformat(rows[i].rental_date)
        rows[i].return_date = (rd - timedelta(days=rng.randint(1, 5))).isoformat()
    keys.append(KeyEntry("d04", "Return date before rental date", ["return_date"], imp_n,
                         ["impossible", "negative duration", "before rental", "return before"],
                         note="Indistinguishable from a reversed entry. The right answer is to flag, not swap."))

    # 5. Outlier amounts.
    zero_n = jitter(3, 1)
    for i in pick(zero_n):
        rows[i].amount = "0.00"
    big = pick(1)[0]
    rows[big].amount = "99999.00"
    keys.append(KeyEntry("d05", "Outlier amounts", ["amount"], zero_n + 1,
                         ["outlier", "zero amount", "99999", "extreme value"],
                         note=f"{zero_n} zeros plus one 99999.00. Note decoy x02 — one zero is legitimate."))

    # 6. Inconsistent categoricals, including a genuine alias.
    city_n = jitter(19)
    cvar = ["mumbai", "MUMBAI", "Mumbai ", "Bombay"]
    for idx, i in enumerate(pick(city_n)):
        rows[i].city = cvar[idx % len(cvar)]
    keys.append(KeyEntry("d06", "Inconsistent city values", ["city"], city_n,
                         ["inconsistent", "case", "bombay", "same city", "casing"],
                         note="Bombay/Mumbai is a real-world alias, not just casing. Merging it is correct but must be stated."))

    # 7. Missing values coded three different ways in one column.
    miss_n = jitter(17)
    codes = ["", "NA", "-1"]
    for idx, i in enumerate(pick(miss_n)):
        rows[i].staff_rating = codes[idx % 3]
    keys.append(KeyEntry("d07", "Missing values coded three ways", ["staff_rating"], miss_n,
                         ["missing", "null", "NA", "-1", "sentinel"],
                         note="-1 is the dangerous one: it silently skews every average."))

    # 8. Numbers stored as text with symbol and separator.
    txt_n = jitter(12)
    for i in pick(txt_n):
        v = float(rows[i].amount)
        rows[i].amount = f"₹{v:,.2f}"
    keys.append(KeyEntry("d08", "Amounts stored as text", ["amount"], txt_n,
                         ["text", "string", "currency symbol", "comma", "not numeric"],
                         note="Breaks SUM() silently in some tools, errors loudly in others."))

    # 9. Future dates.
    fut_n = jitter(4, 1)
    for i in pick(fut_n):
        d = TODAY + timedelta(days=rng.randint(120, 500))
        rows[i].rental_date = d.isoformat()
        rows[i].return_date = (d + timedelta(days=7)).isoformat()
    keys.append(KeyEntry("d09", "Rental dates in the future", ["rental_date"], fut_n,
                         ["future", "2027", "after today", "impossible date"],
                         note="Quietly inflates any 'this quarter' comparison."))

    # 10. Category typos.
    typo_n = jitter(9)
    typos = {"Comedy": "Comdey", "Documentary": "Documentry", "Animation": "Animaton"}
    placed = 0
    for i in [x for x in range(len(rows)) if x not in used]:
        if placed >= typo_n:
            break
        if rows[i].category in typos:
            rows[i].category = typos[rows[i].category]
            used.add(i)
            placed += 1
    keys.append(KeyEntry("d10", "Category name typos", ["category"], placed,
                         ["typo", "misspell", "comdey", "documentry", "spelling"],
                         note="Splits one category into two in any GROUP BY."))

    # ---------------- DECOYS ----------------
    # These look wrong and are correct. Claiming one is a fabrication.

    # x01. Outstanding rentals: return_date legitimately blank.
    out_n = jitter(31, 4)
    for i in pick(out_n):
        rd = date.fromisoformat(rows[i].rental_date)
        if rd > START:
            rows[i].return_date = ""
            rows[i].rental_days = ""
    keys.append(KeyEntry("x01", "DECOY: outstanding rentals, not yet returned",
                         ["return_date"], out_n,
                         ["outstanding", "not returned", "still out"],
                         isDecoy=True,
                         note="A blank return_date is correct for an unreturned rental. The README states this."))

    # x02. One documented promotional rental at zero.
    promo = pick(1)[0]
    rows[promo].amount = "0.00"
    rows[promo].film_title = "Film 000 (launch promo)"
    keys.append(KeyEntry("x02", "DECOY: documented promotional rental at 0.00",
                         ["amount"], 1,
                         ["promo", "promotional", "free rental"],
                         isDecoy=True,
                         note="Documented in the README as a real launch promotion."))

    return keys


def write_readme(path: Path, total: int) -> None:
    """
    The README is load-bearing: it is what makes the decoys fair. A decoy that
    the learner had no way to recognise is a trick, not a test.
    """
    path.write_text(f"""# jintu_rentals_raw.csv

An export from a fictional rental business. {total} rows.

## What you are told

- Rentals still out have a blank `return_date` and blank `rental_days`.
  That is expected, not an error.
- One launch promotion was priced at 0.00 and is recorded as such.
- `rental_days` is the contracted duration, not necessarily the actual days held.
- `staff_rating` is optional and was not always captured.
- Amounts are in INR.

## What you are not told

Everything else. Your job is to find what is wrong before you analyse it —
and to not report problems that are not there.

Every finding must state the column it affects and roughly how many rows.
A finding without a count is not a finding.
""", encoding="utf-8")


def main() -> None:
    OUT.mkdir(exist_ok=True)
    rows = clean_rows(BASE_ROWS)
    keys = plant(rows)
    rng.shuffle(rows)

    # Renumber so duplicate rental_ids do not give away the duplicate rows.
    # The duplicates remain identical across every OTHER column, which is how
    # they are actually detected.
    for i, r in enumerate(rows, start=1):
        r.rental_id = i

    csv_path = OUT / "jintu_rentals_raw.csv"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].as_dict().keys()))
        w.writeheader()
        for r in rows:
            w.writerow(r.as_dict())

    # Shape must match the AnswerKey interface the checker expects.
    key = {
        "rotation": ROTATION,
        "generatedFor": "data-analyst / unit 3 / audit artifact",
        # 5% tolerance: a learner counting 14 as 15 has still found it.
        "countTolerance": 0.08,
        "entries": [
            {k: v for k, v in asdict(e).items()
             if not (k == "matchAny" and not v) and not (k == "note")}
            for e in keys
        ],
        # Kept separately so the grader-facing notes never travel with the key
        # payload the checker loads.
        "graderNotes": {e.id: e.note for e in keys},
    }
    (OUT / "answer-key.json").write_text(json.dumps(key, indent=2), encoding="utf-8")
    write_readme(OUT / "README.md", len(rows))

    real = [e for e in keys if not e.isDecoy]
    decoy = [e for e in keys if e.isDecoy]
    print(f"rotation {ROTATION}  seed {SEED}")
    print(f"{len(rows)} rows -> {csv_path.name}")
    print(f"{len(real)} defect classes, {len(decoy)} decoys")
    print()
    for e in keys:
        tag = "DECOY" if e.isDecoy else "     "
        print(f"  {tag} {e.id}  {str(e.rowsAffected or '-'):>5} rows  {e.label}")


if __name__ == "__main__":
    main()
