/**
 * roundtrip.ts — proves the generator, the answer key and the checker agree.
 *
 * The generator emits a key. verify.py proves the counts are detectable from
 * the CSV. This closes the loop: it feeds that real key into the REAL
 * answerKeyMatch checker with plausible learner submissions and asserts the
 * scoring behaves.
 *
 * Run: node --experimental-strip-types roundtrip.ts
 */
import { readFileSync } from 'node:fs';
import { grade } from '../grading/src/grade.ts';
import type { Rubric, Submission, GradeContext } from '../grading/src/types.ts';

const key = JSON.parse(readFileSync(new URL('./out/answer-key.json', import.meta.url), 'utf8'));
const ctx: GradeContext = { loadKey: async () => key, maxExamples: 3 };

// The rubric from the curriculum spec: data-audit-v3.
const detection: Rubric = {
  id: 'data-audit-v3-detection', total: 5,
  criteria: [{
    name: 'Defect classes found', weight: 5, check: 'detectable',
    checker: 'answer_key_match',
    config: { keyRef: 'keys/da3/u3-audit.json', mode: 'detection', perClasses: 2, capAt: 5 },
  }],
};
const fabrication: Rubric = {
  id: 'data-audit-v3-fabrication', total: 1,
  criteria: [{
    name: 'No fabricated defects', weight: 1, check: 'detectable',
    checker: 'answer_key_match',
    config: { keyRef: 'keys/da3/u3-audit.json', mode: 'fabrication' },
  }],
};

const sub = (findings: unknown[]): Submission =>
  ({ id: 's', assignmentId: 'a', payload: { findings } });

// Exact counts, as verify.py independently confirmed them from the CSV.
const TRUE_FINDINGS = [
  { column: 'rental_id',     rows_affected: 15, description: 'exact duplicate rows' },
  { column: 'customer_name', rows_affected: 10, description: 'near duplicate names, casing and whitespace' },
  { column: 'rental_date',   rows_affected: 22, description: 'mixed date formats' },
  { column: 'return_date',   rows_affected: 8,  description: 'return before rental, impossible' },
  { column: 'amount',        rows_affected: 3,  description: 'zero and extreme outlier amounts' },
  { column: 'city',          rows_affected: 19, description: 'inconsistent casing, Bombay alias' },
  { column: 'staff_rating',  rows_affected: 14, description: 'missing coded as blank, NA and -1' },
  { column: 'amount',        rows_affected: 13, description: 'amounts stored as text with symbol' },
  { column: 'rental_date',   rows_affected: 5,  description: 'future dates' },
  { column: 'category',      rows_affected: 6,  description: 'category typos' },
];

let ok = 0, bad = 0;
const t = async (name: string, fn: () => Promise<void>) => {
  try { await fn(); ok++; console.log(`  ok  ${name}`); }
  catch (e) { bad++; console.log(`FAIL  ${name}\n      ${(e as Error).message}`); }
};
const eq = (a: unknown, b: unknown, m = '') => {
  if (JSON.stringify(a) !== JSON.stringify(b))
    throw new Error(`${m} expected ${JSON.stringify(b)}, got ${JSON.stringify(a)}`);
};

console.log('\nround trip: generator key -> real checker\n');

await t('a perfect audit scores full detection marks', async () => {
  const r = await grade(sub(TRUE_FINDINGS), detection, ctx);
  eq(r.score, 5);
  eq(r.evidencedScore, 5, 'detectable points must count as evidenced');
});

await t('finding 8 of 10 classes still caps at full marks', async () => {
  const r = await grade(sub(TRUE_FINDINGS.slice(0, 8)), detection, ctx);
  eq(r.score, 4, '8 classes at 1-per-2 = 4, under the cap of 5');
});

await t('finding 4 classes scores 2', async () => {
  const r = await grade(sub(TRUE_FINDINGS.slice(0, 4)), detection, ctx);
  eq(r.score, 2);
});

await t('a count off by one still matches, inside 8% tolerance', async () => {
  const r = await grade(sub([{ column: 'rental_date', rows_affected: 21 }]), detection, ctx);
  if (!r.results[0].detail.includes('1 of 10')) throw new Error(r.results[0].detail);
});

await t('a wildly wrong count does not match', async () => {
  const r = await grade(sub([{ column: 'rental_date', rows_affected: 400 }]), detection, ctx);
  if (!r.results[0].detail.includes('0 of 10')) throw new Error(r.results[0].detail);
});

await t('vague prose with no count earns nothing', async () => {
  const r = await grade(sub([
    { description: 'the data is quite messy overall' },
    { description: 'there are some duplicates I think' },
  ]), detection, ctx);
  eq(r.score, 0);
});

await t('a clean audit keeps the fabrication point', async () => {
  const r = await grade(sub(TRUE_FINDINGS), fabrication, ctx);
  eq(r.score, 1);
});

await t('claiming the outstanding-rentals decoy costs the point', async () => {
  const r = await grade(sub([
    ...TRUE_FINDINGS.slice(0, 3),
    { column: 'return_date', rows_affected: 34, description: 'missing return dates, broken data' },
  ]), fabrication, ctx);
  eq(r.score, 0, 'x01 is correct data — claiming it is a fabrication');
});

await t('claiming the promo decoy costs the point', async () => {
  const r = await grade(sub([
    { column: 'amount', rows_affected: 1, description: 'a rental priced at zero, clearly an error' },
  ]), fabrication, ctx);
  eq(r.score, 0, 'x02 is a documented promotion');
});

await t('an invented count costs the point', async () => {
  const r = await grade(sub([{ column: 'city', rows_affected: 900 }]), fabrication, ctx);
  eq(r.score, 0);
});

await t('feedback never names a defect the learner missed', async () => {
  const r = await grade(sub(TRUE_FINDINGS.slice(0, 2)), detection, ctx);
  const text = [r.results[0].detail, ...(r.results[0].examples ?? [])].join(' ').toLowerCase();
  for (const leak of ['future date', 'typo', 'staff_rating', 'text with symbol', 'bombay']) {
    if (text.includes(leak)) throw new Error(`feedback leaked "${leak}"`);
  }
});

await t('grader notes are not in the payload the checker loads', async () => {
  // graderNotes lives beside entries in the file, but must never be surfaced
  // in learner-facing output.
  const r = await grade(sub(TRUE_FINDINGS.slice(0, 2)), detection, ctx);
  const text = JSON.stringify(r);
  if (text.includes('Detect with GROUP BY') || text.includes('indistinguishable'))
    throw new Error('grader notes leaked into the report');
});

console.log(`\n${ok} passed, ${bad} failed\n`);
if (bad) process.exit(1);
