# Seeded defect datasets

The proprietary layer. The answer keys do not exist on the internet, which is what makes these units gradeable at zero cost and un-replicable by a competitor with the same idea and a good prompt.

```
python3 seed_rentals.py                          # generate CSV + key
python3 verify.py                                # prove the key matches the data
node --experimental-strip-types roundtrip.ts     # prove the checker agrees
```

**Current state: 12 defect classes verified exact, 12 round-trip tests passing.**

---

## Gitignore this before your first commit

```gitignore
# Answer keys — never in the public repo
seeder/out/answer-key.json
**/answer-key*.json
supabase/answer-keys/
```

The CSV is safe to publish; the key is not. In production the key goes into the `answer_keys` table or a private storage bucket, both of which have no RLS policy by design — service role only, resolved inside the grading edge function.

---

## What's in the dataset

`jintu_rentals_raw.csv` — 4,215 rows, a fictional rental business.

| id | Class | Rows | Column |
|---|---|---|---|
| d01 | Exact duplicate rows | 15 | `rental_id` |
| d02 | Near-duplicate customer names | 10 | `customer_name` |
| d03 | Mixed date formats | 22 | `rental_date` |
| d04 | Return date before rental date | 8 | `return_date` |
| d05 | Zero and extreme amounts | 3 | `amount` |
| d06 | Inconsistent city values | 19 | `city` |
| d07 | Missing coded three ways | 14 | `staff_rating` |
| d08 | Amounts stored as text | 13 | `amount` |
| d09 | Future rental dates | 5 | `rental_date` |
| d10 | Category typos | 6 | `category` |
| **x01** | **DECOY** — outstanding rentals, blank return date | 34 | `return_date` |
| **x02** | **DECOY** — documented promotional rental at 0.00 | 1 | `amount` |

Rates run from 0.07% to 0.5% of rows. A defect present in 40% of rows is a tutorial; one in 0.3% is the job.

---

## Three design decisions

### The row count is the fingerprint

A learner writes prose. The key holds structure. Matching them without an LLM, and without a dropdown that hands over the answer, seemed impossible — until you require every finding to state **which column and roughly how many rows**. Then the match is `(column, count)`: objective, free, unguessable.

Vague prose scores nothing. Not because we judged the writing, but because a finding without a count isn't a finding — which is also true on the job.

Tolerance is 8%, so someone counting 22 as 21 still gets credit.

### The decoys are the point

`x01` is 34 rentals with a blank `return_date` because they haven't been returned. `x02` is a single rental at ₹0.00 because it was a launch promotion. Both look like defects. Both are correct data, **and both are documented in the dataset README** — a decoy the learner had no way to recognise is a trick, not a test.

Claiming either costs the fabrication point. Without decoys you're testing thoroughness, which is what a chatbot is already good at. With them you're testing judgement, which it isn't.

### Rotation expires a leaked key

`ROTATION` seeds the RNG, so bumping it moves every count. A key circulating from last quarter scores nothing. Bump it quarterly and assume anything older than three rotations is public.

---

## Why `verify.py` exists

`plant()` applies ten mutations to the same 4,200 rows. They collide, and a collision silently drifts the counts — the key would claim 15 duplicates while the data held 13, and every learner who correctly reported 13 would be marked wrong.

It caught exactly that on the first run: `d05` claimed 3 zero-or-extreme amounts, the data held 4, because the promo decoy also sets an amount to `0.00`. The attribution was wrong, not the data — but a generator without a verifier is a generator you can't trust, and this one now proves all twelve counts independently from the CSV alone.

**Re-run `verify.py` after every rotation.** A drifted key is worse than no key: it fails correct learners.

---

## Still to build

Same pattern, three more assets:

| Asset | For | Effort |
|---|---|---|
| `jintu_ads_broken.csv` + key | Amazon Ads unit 3 — 9 faults, 3 decoys | ~1 day |
| `jintu_search_terms.csv` + key | Amazon Ads unit 4 — negate/promote/hold lists | ~1 day |
| `jintu_unit_economics.xlsx` + key | Amazon Ads unit 1 — 24 cells to 2 decimals | ~half day |
| `audit.jintu.in/site-a` + key | Search & AI Visibility units 1–3 — 12 defects, 2 decoys | ~3 days |

The ads export is the highest-value next one: Amazon Ads scores 67% machine-checked, higher than Data Analyst's 55%, because a campaign export takes planted misconfigurations exactly the way a CSV takes planted defects.
