#!/usr/bin/env python3
"""
verify.py — independently detects every planted defect from the CSV alone and
compares against the answer key.

WHY THIS EXISTS
plant() applies ten mutations to the same rows. They can overwrite each other
and silently drift the counts, which would mean the key claims 15 duplicates
while the data holds 13 — and every learner who correctly reports 13 would be
marked wrong. A generator without a verifier is a generator you cannot trust.

This is also the reference detection for each class, so it doubles as the
grader's own working.
"""

from __future__ import annotations
import csv, json, re
from collections import Counter
from datetime import date
from pathlib import Path

OUT = Path(__file__).parent / "out"
TODAY = date(2026, 8, 12)

rows = list(csv.DictReader((OUT / "jintu_rentals_raw.csv").open(encoding="utf-8")))
key = json.loads((OUT / "answer-key.json").read_text(encoding="utf-8"))
entries = {e["id"]: e for e in key["entries"]}


def norm_name(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip()).lower()


def parse_iso(s: str):
    try:
        return date.fromisoformat(s)
    except (ValueError, TypeError):
        return None


# d01 — duplicate rows, ignoring rental_id (renumbered after duplication).
sig = Counter(
    tuple(r[c] for c in rows[0] if c != "rental_id") for r in rows
)
d01 = sum(n - 1 for n in sig.values() if n > 1)

# d02 — customer names whose normalised form collides with a differently-spelt row.
by_norm: dict[str, set[str]] = {}
for r in rows:
    by_norm.setdefault(norm_name(r["customer_name"]), set()).add(r["customer_name"])
messy = {k for k, v in by_norm.items() if len(v) > 1}
d02 = sum(1 for r in rows if norm_name(r["customer_name"]) in messy
          and r["customer_name"] != max(by_norm[norm_name(r["customer_name"])], key=len).strip())
# Simpler, matching what a learner would report: rows not in canonical form.
d02 = sum(1 for r in rows if norm_name(r["customer_name"]) in messy
          and r["customer_name"] not in ("Rajesh Kumar",))

# d03 — rental_date not in ISO form.
d03 = sum(1 for r in rows if r["rental_date"] and parse_iso(r["rental_date"]) is None)

# d04 — return before rental, both parseable.
d04 = 0
for r in rows:
    a, b = parse_iso(r["rental_date"]), parse_iso(r["return_date"])
    if a and b and b < a:
        d04 += 1

# d05 — zero or extreme amounts, EXCLUDING the documented promo (x02).
# These two classes collide on amount=0.00: without this exclusion the
# verifier attributes the promo row to d05 and hides real drift behind a
# known overlap. The README documents the promo, so a careful learner
# excludes it too — and the tolerance covers those who do not.
def amt(s: str):
    t = s.replace("₹", "").replace(",", "").strip()
    try:
        return float(t)
    except ValueError:
        return None
d05 = sum(
    1 for r in rows
    if (v := amt(r["amount"])) is not None
    and (v == 0.0 or v > 10000)
    and "promo" not in r["film_title"].lower()
)

# d06 — city not in canonical form.
canon = {"Mumbai", "Pune", "Bengaluru", "Chennai", "Hyderabad", "Kolkata",
         "Ahmedabad", "Jaipur", "Lucknow", "Kochi"}
d06 = sum(1 for r in rows if r["city"] not in canon)

# d07 — staff_rating missing, coded three ways.
d07 = sum(1 for r in rows if r["staff_rating"].strip() in ("", "NA", "-1"))

# d08 — amount holds a symbol or separator.
d08 = sum(1 for r in rows if ("₹" in r["amount"] or "," in r["amount"]))

# d09 — rental_date after today.
d09 = 0
for r in rows:
    d = parse_iso(r["rental_date"])
    if d and d > TODAY:
        d09 += 1

# d10 — misspelt categories.
bad_cat = {"Comdey", "Documentry", "Animaton"}
d10 = sum(1 for r in rows if r["category"] in bad_cat)

# x01 — blank return_date (the decoy).
x01 = sum(1 for r in rows if r["return_date"].strip() == "")

# x02 — the documented promo.
x02 = sum(1 for r in rows if "promo" in r["film_title"].lower())

found = {"d01": d01, "d02": d02, "d03": d03, "d04": d04, "d05": d05,
         "d06": d06, "d07": d07, "d08": d08, "d09": d09, "d10": d10,
         "x01": x01, "x02": x02}

tol = key.get("countTolerance", 0.08)
print(f"{len(rows)} rows · tolerance ±{tol:.0%}\n")
print(f"{'id':<5} {'key':>6} {'found':>6}  {'':<3} class")
print("-" * 62)

bad = []
for eid, claimed_e in entries.items():
    claimed = claimed_e.get("rowsAffected")
    actual = found.get(eid)
    if claimed is None or actual is None:
        print(f"{eid:<5} {'-':>6} {'-':>6}  ??  {claimed_e['label']}")
        continue
    ok = abs(actual - claimed) <= max(1, claimed * tol)
    mark = "ok " if ok else "OFF"
    if not ok:
        bad.append((eid, claimed, actual, claimed_e["label"]))
    print(f"{eid:<5} {claimed:>6} {actual:>6}  {mark}  {claimed_e['label']}")

print()
if bad:
    print(f"{len(bad)} class(es) drifted — the key would mark correct answers wrong:\n")
    for eid, c, a, lbl in bad:
        print(f"  {eid}: key says {c}, data holds {a}  ({lbl})")
    raise SystemExit(1)
print("Every planted count is independently detectable within tolerance.")
